<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin_guard();
        $this->load->model(array('Order_model', 'Project_model', 'Rsvp_model', 'Wish_model', 'Guest_model', 'Activity_log_model'));
    }

    public function index()
    {
        $data = $this->admin_data('Dashboard');
        $data['total_orders'] = $this->Order_model->count_all();
        $data['total_projects'] = $this->Project_model->count_all();
        $data['total_published'] = $this->Project_model->count_published();
        $data['total_rsvp'] = $this->Rsvp_model->count_all();
        $data['total_wish'] = $this->Wish_model->count_all();
        $data['total_guest'] = $this->Guest_model->count_all();
        $data['latest_rsvps'] = $this->Rsvp_model->latest(5);
        $data['latest_wishes'] = $this->Wish_model->latest(5);
        $data['latest_activities'] = $this->Activity_log_model->latest(8);
        $this->load->view('admin/dashboard/index', $data);
    }
}
