# CI3 Invitation Business V4.3 Production

Upgrade yang ditambahkan pada V4.3:
- fine-grained role permission per aksi (view/create/update/delete/publish/export)
- preview mobile & desktop untuk template
- timeline project / histori revisi internal
- helper copy semua link guest + copy link per guest
- dashboard operasional dengan ringkasan bulanan order dan status project

Default login seed:
- admin / admin123
- cs / admin123

Pastikan folder berikut writable:
- uploads/templates
- uploads/projects
- uploads/projects/gallery
- uploads/users
- uploads/payments
