# CI3 Invitation Business V4 Operational

Versi ini ditujukan agar lebih siap dipakai operasional harian.

## Tambahan utama
- Admin users CRUD + role
- Upload thumbnail template
- Upload hero image project
- Customer lebih lengkap: email, source, address
- Order operasional: order_no, PIC, price, discount, final price, DP, paid amount, payment method, payment date, deadline
- Project operasional: PIC, deadline, revision notes, workflow status
- Moderasi ucapan/wishes: pending / approved / rejected
- RSVP menyimpan guest_id bila link personalized dipakai
- Dashboard operasional
- Laporan ringkas

## Login default
- admin / admin123

## Install
1. Siapkan instalasi CodeIgniter 3 standar.
2. Timpa folder `application/` dan `uploads/` menggunakan isi zip ini.
3. Import `database/ci3_invitation_business_v4_operational.sql`.
4. Atur `application/config/database.php`.
5. Atur `application/config/config.php` untuk `base_url`.
6. Pastikan folder `uploads/templates`, `uploads/projects`, `uploads/users` writable.
