<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
    protected $current_admin = null;

    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url', 'app'));
        $this->load->library('session');
        if ($this->session->userdata('admin_id')) {
            $this->load->model('User_model');
            $this->current_admin = $this->User_model->find((int) $this->session->userdata('admin_id'));
        }
    }

    protected function admin_guard()
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/login');
        }
    }

    protected function admin_data($title = 'Admin Panel')
    {
        return array(
            'page_title' => $title,
            'admin_name' => $this->session->userdata('admin_name'),
            'current_admin' => $this->current_admin,
        );
    }

    protected function set_flash($type, $message)
    {
        $this->session->set_flashdata('flash_type', $type);
        $this->session->set_flashdata('flash_message', $message);
    }

    protected function upload_image($field_name, $target_folder, $old_path = '', $allowed = 'jpg|jpeg|png|webp|gif')
    {
        if (empty($_FILES[$field_name]['name'])) {
            return $old_path;
        }

        $upload_dir = FCPATH . trim($target_folder, '/') . '/';
        if (!is_dir($upload_dir)) {
            @mkdir($upload_dir, 0777, TRUE);
        }

        $config = array(
            'upload_path' => $upload_dir,
            'allowed_types' => $allowed,
            'max_size' => 4096,
            'encrypt_name' => TRUE,
        );

        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        if (!$this->upload->do_upload($field_name)) {
            $this->set_flash('danger', strip_tags($this->upload->display_errors('', '')));
            return FALSE;
        }

        $data = $this->upload->data();
        $new_path = trim($target_folder, '/') . '/' . $data['file_name'];

        if ($old_path && strpos($old_path, trim($target_folder, '/').'/') === 0) {
            $old_file = FCPATH . ltrim($old_path, '/');
            if (is_file($old_file)) {
                @unlink($old_file);
            }
        }

        return $new_path;
    }
}
