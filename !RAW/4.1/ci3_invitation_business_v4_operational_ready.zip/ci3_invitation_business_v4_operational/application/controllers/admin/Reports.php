<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin_guard();
        $this->load->model(array('Order_model', 'Project_model', 'Guest_model', 'Rsvp_model', 'Wish_model'));
    }

    public function index()
    {
        $data = $this->admin_data('Laporan Ringkas');
        $data['orders'] = $this->Order_model->all();
        $data['projects'] = $this->Project_model->all();
        $data['guest_total'] = $this->Guest_model->count_all();
        $data['guest_opened'] = $this->Guest_model->count_opened();
        $data['rsvp_total'] = $this->Rsvp_model->count_all();
        $data['attendee_total'] = $this->Rsvp_model->total_attendees();
        $data['wish_total'] = $this->Wish_model->count_all();
        $data['wish_pending'] = $this->Wish_model->count_pending();
        $this->load->view('admin/reports/index', $data);
    }
}
